ALTER TABLE "balance_snapshot" ALTER COLUMN "availableBalance" SET DATA TYPE text;--> statement-breakpoint
ALTER TABLE "balance_snapshot" ALTER COLUMN "totalBalance" SET DATA TYPE text;--> statement-breakpoint
ALTER TABLE "balance_snapshot" ALTER COLUMN "totalPnl" SET DATA TYPE text;