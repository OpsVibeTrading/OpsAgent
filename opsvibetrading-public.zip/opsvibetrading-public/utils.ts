export function formatNumber(num: number | string): number {
  return Number(num);
}
